# ============================================================
# LAB Active Directory - 10-Configure-Server-Local-RDP.ps1
# Aggiunta gruppi RDP domain local ai gruppi locali server
# Idempotente; include server futuri commentati
# ============================================================

$ErrorActionPreference = "Stop"
$ScriptRoot = "C:\LAB-AD\Scripts"
if (-not $Global:LabDN) { & (Join-Path $ScriptRoot "00-Init-LAB-Session.ps1") }

Invoke-Command -ComputerName "SRV-FS-001" -ScriptBlock {
    param($NetBIOS)
    Add-LocalGroupMember -Group "Remote Desktop Users" -Member "$NetBIOS\DL_RDP_SRV-FS-001_Admins" -ErrorAction SilentlyContinue
} -ArgumentList $NetBIOS

# Futuri server: scommentare quando saranno attivati e joined al dominio.
# Invoke-Command -ComputerName "SRV-APP-001" -ScriptBlock {
#     param($NetBIOS)
#     Add-LocalGroupMember -Group "Remote Desktop Users" -Member "$NetBIOS\DL_RDP_SRV-APP-001_Admins" -ErrorAction SilentlyContinue
# } -ArgumentList $NetBIOS
#
# Invoke-Command -ComputerName "SRV-DB-001" -ScriptBlock {
#     param($NetBIOS)
#     Add-LocalGroupMember -Group "Remote Desktop Users" -Member "$NetBIOS\DL_RDP_SRV-DB-001_Admins" -ErrorAction SilentlyContinue
# } -ArgumentList $NetBIOS

Write-Host "[OK] 10 completato." -ForegroundColor Green
