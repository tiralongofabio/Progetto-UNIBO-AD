# ============================================================
# LAB Active Directory - 12-Run-Basic-Checks.ps1
# Verifiche sintetiche post-deploy
# ============================================================

$ErrorActionPreference = "Continue"
$ScriptRoot = "C:\LAB-AD\Scripts"
if (-not $Global:LabDN) { & (Join-Path $ScriptRoot "00-Init-LAB-Session.ps1") }
Import-Module ActiveDirectory
Import-Module GroupPolicy

Write-Host "=== Dominio/DNS ===" -ForegroundColor Cyan
Get-ADDomain
Get-ADDomainController
Resolve-DnsName $DomainDNS
Resolve-DnsName "SRV-FS-001.$DomainDNS"

Write-Host "=== OU ===" -ForegroundColor Cyan
Get-ADOrganizationalUnit -SearchBase $LabDN -Filter * | Select-Object Name, DistinguishedName | Sort-Object DistinguishedName | Format-Table -AutoSize

Write-Host "=== Gruppi ===" -ForegroundColor Cyan
$GroupsSecurityDN = "OU=Security,OU=Groups,$LabDN"
Get-ADGroup -SearchBase $GroupsSecurityDN -Filter * | Select-Object Name, GroupScope | Sort-Object Name | Format-Table -AutoSize

Write-Host "=== Utenti ===" -ForegroundColor Cyan
Get-ADUser -SearchBase $LabDN -Filter * -Properties Description | Select-Object SamAccountName, Enabled, Description | Sort-Object SamAccountName | Format-Table -AutoSize

Write-Host "=== File server ===" -ForegroundColor Cyan
Test-WSMan SRV-FS-001
Test-NetConnection SRV-FS-001 -Port 445
Invoke-Command -ComputerName SRV-FS-001 -ScriptBlock { Get-SmbShare -Name Departments,Governance,Shared; Test-Path D:\Shares }

Write-Host "=== GPO ===" -ForegroundColor Cyan
Get-GPO -All | Where-Object DisplayName -like "GPO-LAB-*" | Select-Object DisplayName | Sort-Object DisplayName | Format-Table -AutoSize

Write-Host "[OK] 12 completato." -ForegroundColor Green
