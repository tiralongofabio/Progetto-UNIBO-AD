# ============================================================
# LAB Active Directory - 01-Load-LAB-Helpers.ps1
# Funzioni helper idempotenti per OU, gruppi, utenti, GPO, ACL
# Da caricare con dot sourcing:
# . C:\LAB-AD\Scripts\01-Load-LAB-Helpers.ps1
# ============================================================

$ErrorActionPreference = "Stop"
Import-Module ActiveDirectory -ErrorAction Stop
Import-Module GroupPolicy -ErrorAction Stop

function Ensure-ADOU {
    param(
        [Parameter(Mandatory)] [string] $Name,
        [Parameter(Mandatory)] [string] $Path,
        [string] $Description = "LAB OU"
    )
    $TargetDN = "OU=$Name,$Path"
    $Existing = Get-ADOrganizationalUnit -LDAPFilter "(distinguishedName=$TargetDN)" -ErrorAction SilentlyContinue
    if (-not $Existing) {
        New-ADOrganizationalUnit -Name $Name -Path $Path -Description $Description -ProtectedFromAccidentalDeletion $true
        Write-Host "[OK] OU creata: $TargetDN" -ForegroundColor Green
    } else {
        Write-Host "[SKIP] OU già presente: $TargetDN" -ForegroundColor Yellow
    }
}

function Ensure-ADGroup {
    param(
        [Parameter(Mandatory)] [string] $Name,
        [Parameter(Mandatory)] [string] $Path,
        [Parameter(Mandatory)] [ValidateSet("Global", "DomainLocal", "Universal")] [string] $Scope,
        [string] $Description = "LAB security group"
    )
    $Existing = Get-ADGroup -LDAPFilter "(sAMAccountName=$Name)" -ErrorAction SilentlyContinue
    if (-not $Existing) {
        New-ADGroup -Name $Name -SamAccountName $Name -GroupCategory Security -GroupScope $Scope -Path $Path -Description $Description
        Write-Host "[OK] Gruppo creato: $Name" -ForegroundColor Green
    } else {
        Write-Host "[SKIP] Gruppo già presente: $Name" -ForegroundColor Yellow
    }
}

function Ensure-ADGroupMember {
    param(
        [Parameter(Mandatory)] [string] $Group,
        [Parameter(Mandatory)] [string[]] $Members
    )
    foreach ($Member in $Members) {
        try {
            $ExistingMember = Get-ADGroupMember -Identity $Group -Recursive -ErrorAction Stop | Where-Object {
                $_.SamAccountName -eq $Member -or $_.Name -eq $Member
            }
            if (-not $ExistingMember) {
                Add-ADGroupMember -Identity $Group -Members $Member -ErrorAction Stop
                Write-Host "[OK] Aggiunto $Member a $Group" -ForegroundColor Green
            } else {
                Write-Host "[SKIP] $Member già membro di $Group" -ForegroundColor Yellow
            }
        }
        catch {
            Write-Warning "Errore membership: $Member -> $Group. Dettaglio: $_"
        }
    }
}

function Ensure-ADUserLab {
    param(
        [Parameter(Mandatory)] [string] $SamAccountName,
        [Parameter(Mandatory)] [string] $GivenName,
        [Parameter(Mandatory)] [string] $Surname,
        [Parameter(Mandatory)] [string] $Path,
        [Parameter(Mandatory)] [securestring] $Password,
        [string] $Description = "LAB user",
        [bool] $Enabled = $true,
        [bool] $ChangePasswordAtLogon = $false,
        [bool] $PasswordNeverExpires = $false,
        [bool] $AccountNotDelegated = $false
    )
    $Existing = Get-ADUser -LDAPFilter "(sAMAccountName=$SamAccountName)" -ErrorAction SilentlyContinue
    if (-not $Existing) {
        $DisplayName = "$GivenName $Surname"
        $UPN = "$SamAccountName@$Global:DomainDNS"
        New-ADUser -Name $DisplayName -GivenName $GivenName -Surname $Surname -DisplayName $DisplayName `
            -SamAccountName $SamAccountName -UserPrincipalName $UPN -Path $Path -AccountPassword $Password `
            -Enabled $Enabled -ChangePasswordAtLogon $ChangePasswordAtLogon -Description $Description
        Write-Host "[OK] Utente creato: $SamAccountName" -ForegroundColor Green
    } else {
        Write-Host "[SKIP] Utente già presente: $SamAccountName" -ForegroundColor Yellow
    }
    Set-ADUser -Identity $SamAccountName -Description $Description -AccountNotDelegated:$AccountNotDelegated
    if ($PasswordNeverExpires) {
        Set-ADUser -Identity $SamAccountName -PasswordNeverExpires $true
    }
}

function Ensure-GPOWithLink {
    param(
        [Parameter(Mandatory)] [string] $Name,
        [Parameter(Mandatory)] [string] $TargetDN,
        [string] $Comment = "LAB GPO"
    )
    $Gpo = Get-GPO -Name $Name -ErrorAction SilentlyContinue
    if (-not $Gpo) {
        $Gpo = New-GPO -Name $Name -Comment $Comment
        Write-Host "[OK] GPO creata: $Name" -ForegroundColor Green
    } else {
        Write-Host "[SKIP] GPO già presente: $Name" -ForegroundColor Yellow
    }
    $Inheritance = Get-GPInheritance -Target $TargetDN
    $ExistingLink = $Inheritance.GpoLinks | Where-Object { $_.DisplayName -eq $Name }
    if (-not $ExistingLink) {
        New-GPLink -Name $Name -Target $TargetDN -LinkEnabled Yes | Out-Null
        Write-Host "[OK] Link GPO $Name -> $TargetDN" -ForegroundColor Green
    } else {
        Write-Host "[SKIP] Link già presente: $Name -> $TargetDN" -ForegroundColor Yellow
    }
}

function Reset-FolderAcl {
    param([Parameter(Mandatory)] [string] $Path)
    $Acl = Get-Acl -Path $Path
    $Acl.SetAccessRuleProtection($true, $false)
    foreach ($Ace in @($Acl.Access)) {
        $Acl.RemoveAccessRule($Ace) | Out-Null
    }
    Set-Acl -Path $Path -AclObject $Acl
}

function Add-FolderAce {
    param(
        [Parameter(Mandatory)] [string] $Path,
        [Parameter(Mandatory)] [string] $Identity,
        [Parameter(Mandatory)] [System.Security.AccessControl.FileSystemRights] $Rights,
        [System.Security.AccessControl.InheritanceFlags] $InheritanceFlags = "ContainerInherit, ObjectInherit",
        [System.Security.AccessControl.PropagationFlags] $PropagationFlags = "None",
        [System.Security.AccessControl.AccessControlType] $Type = "Allow"
    )
    $Acl = Get-Acl -Path $Path
    $Rule = New-Object System.Security.AccessControl.FileSystemAccessRule($Identity, $Rights, $InheritanceFlags, $PropagationFlags, $Type)
    $Acl.AddAccessRule($Rule)
    Set-Acl -Path $Path -AclObject $Acl
}

Write-Host "[OK] Helper LAB caricati." -ForegroundColor Green
