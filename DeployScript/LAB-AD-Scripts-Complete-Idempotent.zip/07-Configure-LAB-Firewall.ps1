# ============================================================
# LAB Active Directory - 07-Configure-LAB-Firewall.ps1
# Regole firewall realistiche per il lab
# Idempotente
# ============================================================

$ErrorActionPreference = "Stop"
$ScriptRoot = "C:\LAB-AD\Scripts"
if (-not $Global:LabDN) { & (Join-Path $ScriptRoot "00-Init-LAB-Session.ps1") }

function Ensure-FirewallRuleLocal {
    param(
        [string]$DisplayName,
        [string]$Direction,
        [string]$Action,
        [string]$Protocol,
        [string]$LocalPort,
        [string]$RemoteAddress,
        [string]$Profile = "Domain"
    )
    if (-not (Get-NetFirewallRule -DisplayName $DisplayName -ErrorAction SilentlyContinue)) {
        New-NetFirewallRule -DisplayName $DisplayName -Direction $Direction -Action $Action -Protocol $Protocol -LocalPort $LocalPort -RemoteAddress $RemoteAddress -Profile $Profile | Out-Null
        Write-Host "[OK] Regola creata: $DisplayName" -ForegroundColor Green
    } else {
        Write-Host "[SKIP] Regola già presente: $DisplayName" -ForegroundColor Yellow
    }
}

# DC01: DNS dal lab
Ensure-FirewallRuleLocal -DisplayName "LAB-Allow-DNS-UDP-In" -Direction Inbound -Action Allow -Protocol UDP -LocalPort 53 -RemoteAddress "10.0.0.0/24"
Ensure-FirewallRuleLocal -DisplayName "LAB-Allow-DNS-TCP-In" -Direction Inbound -Action Allow -Protocol TCP -LocalPort 53 -RemoteAddress "10.0.0.0/24"

# SRV-FS-001: SMB, WinRM, RDP
Invoke-Command -ComputerName "SRV-FS-001" -ScriptBlock {
    function Ensure-FirewallRuleLocalRemote {
        param([string]$DisplayName,[string]$Direction,[string]$Action,[string]$Protocol,[string]$LocalPort,[string]$RemoteAddress,[string]$Profile="Domain")
        if (-not (Get-NetFirewallRule -DisplayName $DisplayName -ErrorAction SilentlyContinue)) {
            New-NetFirewallRule -DisplayName $DisplayName -Direction $Direction -Action $Action -Protocol $Protocol -LocalPort $LocalPort -RemoteAddress $RemoteAddress -Profile $Profile | Out-Null
        }
    }
    Enable-PSRemoting -Force
    Enable-NetFirewallRule -DisplayGroup "Remote Desktop" -ErrorAction SilentlyContinue
    Enable-NetFirewallRule -DisplayGroup "File and Printer Sharing" -ErrorAction SilentlyContinue
    Ensure-FirewallRuleLocalRemote -DisplayName "LAB-Allow-SMB-In" -Direction Inbound -Action Allow -Protocol TCP -LocalPort 445 -RemoteAddress "10.0.0.0/24"
    Ensure-FirewallRuleLocalRemote -DisplayName "LAB-Allow-WinRM-From-DC01" -Direction Inbound -Action Allow -Protocol TCP -LocalPort 5985 -RemoteAddress "10.0.0.1"
    Ensure-FirewallRuleLocalRemote -DisplayName "LAB-Allow-RDP-From-Lab" -Direction Inbound -Action Allow -Protocol TCP -LocalPort 3389 -RemoteAddress "10.0.0.0/24"
}

# Futuri server: predisposizione commentata
# Invoke-Command -ComputerName "SRV-APP-001" -ScriptBlock { <# aggiungere regole app specifiche, WinRM da DC01, RDP dal lab #> }
# Invoke-Command -ComputerName "SRV-DB-001"  -ScriptBlock { <# aggiungere regole DB specifiche, WinRM da DC01, RDP dal lab #> }

Write-Host "[OK] 07 completato." -ForegroundColor Green
