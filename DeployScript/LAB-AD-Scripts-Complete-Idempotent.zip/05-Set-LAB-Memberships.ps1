# ============================================================
# LAB Active Directory - 05-Set-LAB-Memberships.ps1
# Membership completa AGDLP, admin, break-glass, honey, service
# Idempotente
# ============================================================

$ErrorActionPreference = "Stop"
$ScriptRoot = "C:\LAB-AD\Scripts"
if (-not $Global:LabDN) { & (Join-Path $ScriptRoot "00-Init-LAB-Session.ps1") }
if (-not (Get-Command Ensure-ADGroupMember -ErrorAction SilentlyContinue)) { . (Join-Path $ScriptRoot "01-Load-LAB-Helpers.ps1") }
# Carico dataset se non presente
if (-not $Global:LabUsers) { & (Join-Path $ScriptRoot "04-Create-LAB-Users.ps1") }

Write-Host ""
Write-Host "=== 05 - Membership LAB ===" -ForegroundColor Cyan

foreach ($User in $Global:LabUsers) {
    Ensure-ADGroupMember -Group "GG_LAB_AllUsers" -Members @($User.Sam)
    if ($User.Type -eq "Department") { Ensure-ADGroupMember -Group "GG_$($User.Unit)_Users" -Members @($User.Sam) }
    if ($User.Director) {
        Ensure-ADGroupMember -Group "GG_LAB_Directors" -Members @($User.Sam)
        Ensure-ADGroupMember -Group "GG_$($User.Unit)_Director" -Members @($User.Sam)
    }
    if ($User.Board) { Ensure-ADGroupMember -Group "GG_Board_Members" -Members @($User.Sam) }
}

foreach ($SourceSam in @("it.user01", "it.user02", "it.user03", "it.user04")) {
    Ensure-ADGroupMember -Group "GG_LAB_Admins" -Members @("admin.$SourceSam")
}
Ensure-ADGroupMember -Group "GG_LAB_BreakGlass" -Members @("super.user")
Ensure-ADGroupMember -Group "Domain Admins" -Members @("super.user")
Ensure-ADGroupMember -Group "GG_LAB_HoneyObjects" -Members @("admin.backup")
Ensure-ADGroupMember -Group "GG_SecurityApp" -Members @("svc.securityapp")

# Shared globale
Ensure-ADGroupMember -Group "DL_FS_Shared_RO" -Members @("GG_LAB_AllUsers")
Ensure-ADGroupMember -Group "DL_FS_Shared_FC" -Members @("GG_LAB_Admins", "GG_LAB_BreakGlass")

# Aree dipartimentali
foreach ($Dept in $Departments) {
    Ensure-ADGroupMember -Group "DL_FS_${Dept}_Public_WO" -Members @("GG_${Dept}_Users")
    Ensure-ADGroupMember -Group "DL_FS_${Dept}_Public_RO" -Members @("GG_${Dept}_Users")
    Ensure-ADGroupMember -Group "DL_FS_${Dept}_Public_MD" -Members @("GG_${Dept}_Director", "GG_SecurityApp")
    Ensure-ADGroupMember -Group "DL_FS_${Dept}_Public_FC" -Members @("GG_LAB_Admins", "GG_LAB_BreakGlass")
    Ensure-ADGroupMember -Group "DL_FS_${Dept}_Internal_MD" -Members @("GG_${Dept}_Users", "GG_${Dept}_Director", "GG_SecurityApp")
    Ensure-ADGroupMember -Group "DL_FS_${Dept}_Internal_FC" -Members @("GG_LAB_Admins", "GG_LAB_BreakGlass")
    Ensure-ADGroupMember -Group "DL_FS_${Dept}_Confidential_MD" -Members @("GG_${Dept}_Director", "GG_Board_Members", "GG_SecurityApp")
    Ensure-ADGroupMember -Group "DL_FS_${Dept}_Confidential_FC" -Members @("GG_LAB_BreakGlass")
}

# Governance / Board
Ensure-ADGroupMember -Group "DL_FS_Governance_BoardOnly_MD"      -Members @("GG_Board_Members", "GG_SecurityApp")
Ensure-ADGroupMember -Group "DL_FS_Governance_BoardOnly_FC"      -Members @("GG_LAB_BreakGlass")
Ensure-ADGroupMember -Group "DL_FS_Governance_BoardDirectors_MD" -Members @("GG_Board_Members", "GG_LAB_Directors", "GG_SecurityApp")
Ensure-ADGroupMember -Group "DL_FS_Governance_BoardDirectors_FC" -Members @("GG_LAB_BreakGlass")

# RDP amministrativo su server previsti
Ensure-ADGroupMember -Group "DL_RDP_SRV-FS-001_Admins"  -Members @("GG_LAB_Admins", "GG_LAB_BreakGlass")
Ensure-ADGroupMember -Group "DL_RDP_SRV-APP-001_Admins" -Members @("GG_LAB_Admins", "GG_LAB_BreakGlass")
Ensure-ADGroupMember -Group "DL_RDP_SRV-DB-001_Admins"  -Members @("GG_LAB_Admins", "GG_LAB_BreakGlass")

# Computer account server-role: attivo solo se i computer esistono
if (Get-ADComputer -Identity "SRV-FS-001" -ErrorAction SilentlyContinue) {
    Ensure-ADGroupMember -Group "GG_LAB_FileServers" -Members @("SRV-FS-001$")
}
# Futuri server: scommentare quando i computer account esisteranno.
# Ensure-ADGroupMember -Group "GG_LAB_AppServers" -Members @("SRV-APP-001$")
# Ensure-ADGroupMember -Group "GG_LAB_DBServers"  -Members @("SRV-DB-001$")

foreach ($Group in @("GG_LAB_AllUsers", "GG_LAB_Directors", "GG_Board_Members", "GG_LAB_Admins", "GG_LAB_BreakGlass", "GG_LAB_HoneyObjects")) {
    Write-Host "`n[$Group]" -ForegroundColor Yellow
    Get-ADGroupMember $Group | Select-Object Name, SamAccountName, ObjectClass | Sort-Object Name | Format-Table -AutoSize
}
Write-Host "[OK] 05 completato." -ForegroundColor Green
