# ============================================================
# LAB Active Directory - 04-Create-LAB-Users.ps1
# Creazione utenti standard, admin separati, break-glass, honey-object, service account
# Idempotente
# ============================================================

$ErrorActionPreference = "Stop"
$ScriptRoot = "C:\LAB-AD\Scripts"
if (-not $Global:LabDN) { & (Join-Path $ScriptRoot "00-Init-LAB-Session.ps1") }
if (-not (Get-Command Ensure-ADUserLab -ErrorAction SilentlyContinue)) { . (Join-Path $ScriptRoot "01-Load-LAB-Helpers.ps1") }

Write-Host ""
Write-Host "=== 04 - Creazione utenti LAB ===" -ForegroundColor Cyan

$Global:LabUsers = @(
    @{Sam="it.user01";        Given="IT";        Surname="User01"; Unit="IT";        Type="Department"; Director=$true;  Board=$false},
    @{Sam="it.user02";        Given="IT";        Surname="User02"; Unit="IT";        Type="Department"; Director=$false; Board=$false},
    @{Sam="it.user03";        Given="IT";        Surname="User03"; Unit="IT";        Type="Department"; Director=$false; Board=$false},
    @{Sam="it.user04";        Given="IT";        Surname="User04"; Unit="IT";        Type="Department"; Director=$false; Board=$false},
    @{Sam="finance.user01";   Given="Finance";   Surname="User01"; Unit="Finance";   Type="Department"; Director=$true;  Board=$false},
    @{Sam="finance.user02";   Given="Finance";   Surname="User02"; Unit="Finance";   Type="Department"; Director=$false; Board=$false},
    @{Sam="finance.user03";   Given="Finance";   Surname="User03"; Unit="Finance";   Type="Department"; Director=$false; Board=$false},
    @{Sam="finance.user04";   Given="Finance";   Surname="User04"; Unit="Finance";   Type="Department"; Director=$false; Board=$false},
    @{Sam="hr.user01";        Given="HR";        Surname="User01"; Unit="HR";        Type="Department"; Director=$true;  Board=$false},
    @{Sam="hr.user02";        Given="HR";        Surname="User02"; Unit="HR";        Type="Department"; Director=$false; Board=$false},
    @{Sam="hr.user03";        Given="HR";        Surname="User03"; Unit="HR";        Type="Department"; Director=$false; Board=$false},
    @{Sam="hr.user04";        Given="HR";        Surname="User04"; Unit="HR";        Type="Department"; Director=$false; Board=$false},
    @{Sam="marketing.user01"; Given="Marketing"; Surname="User01"; Unit="Marketing"; Type="Department"; Director=$true;  Board=$false},
    @{Sam="marketing.user02"; Given="Marketing"; Surname="User02"; Unit="Marketing"; Type="Department"; Director=$false; Board=$false},
    @{Sam="marketing.user03"; Given="Marketing"; Surname="User03"; Unit="Marketing"; Type="Department"; Director=$false; Board=$false},
    @{Sam="marketing.user04"; Given="Marketing"; Surname="User04"; Unit="Marketing"; Type="Department"; Director=$false; Board=$false},
    @{Sam="sales.user01";     Given="Sales";     Surname="User01"; Unit="Sales";     Type="Department"; Director=$true;  Board=$false},
    @{Sam="sales.user02";     Given="Sales";     Surname="User02"; Unit="Sales";     Type="Department"; Director=$false; Board=$false},
    @{Sam="sales.user03";     Given="Sales";     Surname="User03"; Unit="Sales";     Type="Department"; Director=$false; Board=$false},
    @{Sam="sales.user04";     Given="Sales";     Surname="User04"; Unit="Sales";     Type="Department"; Director=$false; Board=$false},
    @{Sam="board.user01";     Given="Board";     Surname="User01"; Unit="Board";     Type="Governance"; Director=$false; Board=$true},
    @{Sam="board.user02";     Given="Board";     Surname="User02"; Unit="Board";     Type="Governance"; Director=$false; Board=$true},
    @{Sam="board.user03";     Given="Board";     Surname="User03"; Unit="Board";     Type="Governance"; Director=$false; Board=$true},
    @{Sam="board.user04";     Given="Board";     Surname="User04"; Unit="Board";     Type="Governance"; Director=$false; Board=$true}
)

foreach ($User in $Global:LabUsers) {
    if ($User.Type -eq "Governance") { $UserOU = "OU=$($User.Unit),OU=Governance,$LabDN" }
    else { $UserOU = "OU=$($User.Unit),OU=Departments,$LabDN" }
    Ensure-ADUserLab -SamAccountName $User.Sam -GivenName $User.Given -Surname $User.Surname -Path $UserOU `
        -Password $DefaultUserPassword -Description "LAB standard user - $($User.Unit)" -Enabled $true
}

# Admin separati
$Global:AdminSourceUsers = @("it.user01", "it.user02", "it.user03", "it.user04")
$AdminOU = "OU=IT-Admins,OU=Admins,$LabDN"
foreach ($SourceSam in $Global:AdminSourceUsers) {
    Ensure-ADUserLab -SamAccountName "admin.$SourceSam" -GivenName "Admin" -Surname $SourceSam -Path $AdminOU `
        -Password $AdminPassword -Description "LAB separated admin account for $SourceSam" -Enabled $true -AccountNotDelegated $true
}

# Break-glass / super-user
Ensure-ADUserLab -SamAccountName "super.user" -GivenName "Super" -Surname "User" -Path "OU=Break-Glass,OU=Admins,$LabDN" `
    -Password $BreakGlassPassword -Description "LAB BREAK-GLASS emergency account - use only for recovery" -Enabled $true `
    -PasswordNeverExpires $true -AccountNotDelegated $true

# Honey-object: attivo ma senza privilegi reali; verrà monitorato in fasi successive.
Ensure-ADUserLab -SamAccountName "admin.backup" -GivenName "Admin" -Surname "Backup" -Path "OU=Honey-Objects,OU=Admins,$LabDN" `
    -Password $HoneyPassword -Description "LAB HONEY OBJECT - monitored decoy account - no real privileges" -Enabled $true `
    -AccountNotDelegated $true

# Service account predisposto per applicazioni di sicurezza / automazioni future
Ensure-ADUserLab -SamAccountName "svc.securityapp" -GivenName "Service" -Surname "SecurityApp" -Path "OU=SecurityApp,OU=ServiceAccounts,$LabDN" `
    -Password $ServicePassword -Description "LAB service account for security application / scripted access" -Enabled $true `
    -PasswordNeverExpires $true -AccountNotDelegated $true

Get-ADUser -SearchBase $LabDN -Filter * -Properties Description | Select-Object SamAccountName, Enabled, Description, DistinguishedName | Sort-Object SamAccountName | Format-Table -AutoSize
Write-Host "[OK] 04 completato." -ForegroundColor Green
