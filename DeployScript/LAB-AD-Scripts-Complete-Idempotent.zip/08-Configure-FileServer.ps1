# ============================================================
# LAB Active Directory - 08-Configure-FileServer.ps1
# Cartelle, ACL NTFS complete e share SMB su SRV-FS-001
# Idempotente
# ============================================================

$ErrorActionPreference = "Stop"
$ScriptRoot = "C:\LAB-AD\Scripts"
if (-not $Global:LabDN) { & (Join-Path $ScriptRoot "00-Init-LAB-Session.ps1") }

Invoke-Command -ComputerName $FileServerName -ScriptBlock {
    Install-WindowsFeature FS-FileServer -IncludeManagementTools | Out-Null
} 

Invoke-Command -ComputerName $FileServerName -ScriptBlock {
    param($ShareRoot,$DeptRoot,$GovernanceRoot,$BoardRoot,$BoardOnlyPath,$BoardDirPath,$SharedRoot,$Departments,$NetBIOS)

    function Reset-FolderAclLocal {
        param([string]$Path)
        $Acl = Get-Acl -Path $Path
        $Acl.SetAccessRuleProtection($true, $false)
        foreach ($Ace in @($Acl.Access)) { $Acl.RemoveAccessRule($Ace) | Out-Null }
        Set-Acl -Path $Path -AclObject $Acl
    }
    function Add-FolderAceLocal {
        param([string]$Path,[string]$Identity,[System.Security.AccessControl.FileSystemRights]$Rights,
              [System.Security.AccessControl.InheritanceFlags]$InheritanceFlags="ContainerInherit, ObjectInherit",
              [System.Security.AccessControl.PropagationFlags]$PropagationFlags="None")
        $Acl = Get-Acl -Path $Path
        $Rule = New-Object System.Security.AccessControl.FileSystemAccessRule($Identity,$Rights,$InheritanceFlags,$PropagationFlags,"Allow")
        $Acl.AddAccessRule($Rule)
        Set-Acl -Path $Path -AclObject $Acl
    }

    foreach ($Folder in @($ShareRoot,$DeptRoot,$GovernanceRoot,$BoardRoot,$BoardOnlyPath,$BoardDirPath,$SharedRoot)) {
        New-Item -Path $Folder -ItemType Directory -Force | Out-Null
    }
    foreach ($Dept in $Departments) {
        foreach ($Sub in @("", "Public", "Internal", "Confidential")) {
            $Path = if ($Sub) { Join-Path (Join-Path $DeptRoot $Dept) $Sub } else { Join-Path $DeptRoot $Dept }
            New-Item -Path $Path -ItemType Directory -Force | Out-Null
        }
    }

    foreach ($Path in @($ShareRoot,$DeptRoot,$GovernanceRoot,$BoardRoot,$SharedRoot)) {
        Reset-FolderAclLocal $Path
        Add-FolderAceLocal $Path "BUILTIN\Administrators" FullControl
        Add-FolderAceLocal $Path "NT AUTHORITY\SYSTEM" FullControl
    }
    Add-FolderAceLocal $SharedRoot "$NetBIOS\DL_FS_Shared_RO" ReadAndExecute
    Add-FolderAceLocal $SharedRoot "$NetBIOS\DL_FS_Shared_MD" Modify
    Add-FolderAceLocal $SharedRoot "$NetBIOS\DL_FS_Shared_FC" FullControl

    foreach ($Dept in $Departments) {
        $DeptPath = Join-Path $DeptRoot $Dept
        $PublicPath = Join-Path $DeptPath "Public"
        $InternalPath = Join-Path $DeptPath "Internal"
        $ConfidentialPath = Join-Path $DeptPath "Confidential"
        foreach ($Path in @($DeptPath,$PublicPath,$InternalPath,$ConfidentialPath)) {
            Reset-FolderAclLocal $Path
            Add-FolderAceLocal $Path "BUILTIN\Administrators" FullControl
            Add-FolderAceLocal $Path "NT AUTHORITY\SYSTEM" FullControl
        }
        Add-FolderAceLocal $PublicPath "$NetBIOS\DL_FS_${Dept}_Public_WO" "CreateFiles, AppendData, ReadAttributes, ReadPermissions, Synchronize" None None
        Add-FolderAceLocal $PublicPath "$NetBIOS\DL_FS_${Dept}_Public_MD" Modify
        Add-FolderAceLocal $PublicPath "$NetBIOS\DL_FS_${Dept}_Public_RO" ReadAndExecute
        Add-FolderAceLocal $PublicPath "$NetBIOS\DL_FS_${Dept}_Public_FC" FullControl
        Add-FolderAceLocal $InternalPath "$NetBIOS\DL_FS_${Dept}_Internal_MD" Modify
        Add-FolderAceLocal $InternalPath "$NetBIOS\DL_FS_${Dept}_Internal_FC" FullControl
        Add-FolderAceLocal $ConfidentialPath "$NetBIOS\DL_FS_${Dept}_Confidential_MD" Modify
        Add-FolderAceLocal $ConfidentialPath "$NetBIOS\DL_FS_${Dept}_Confidential_FC" FullControl
    }

    foreach ($Path in @($BoardOnlyPath,$BoardDirPath)) {
        Reset-FolderAclLocal $Path
        Add-FolderAceLocal $Path "BUILTIN\Administrators" FullControl
        Add-FolderAceLocal $Path "NT AUTHORITY\SYSTEM" FullControl
    }
    Add-FolderAceLocal $BoardOnlyPath "$NetBIOS\DL_FS_Governance_BoardOnly_MD" Modify
    Add-FolderAceLocal $BoardOnlyPath "$NetBIOS\DL_FS_Governance_BoardOnly_FC" FullControl
    Add-FolderAceLocal $BoardDirPath "$NetBIOS\DL_FS_Governance_BoardDirectors_MD" Modify
    Add-FolderAceLocal $BoardDirPath "$NetBIOS\DL_FS_Governance_BoardDirectors_FC" FullControl

    foreach ($Share in @("Departments","Governance","Shared")) {
        if (Get-SmbShare -Name $Share -ErrorAction SilentlyContinue) { Remove-SmbShare -Name $Share -Force }
    }
    New-SmbShare -Name "Departments" -Path $DeptRoot -FullAccess "BUILTIN\Administrators", "$NetBIOS\GG_LAB_BreakGlass", "$NetBIOS\GG_LAB_Admins" -ChangeAccess "$NetBIOS\GG_LAB_AllUsers" -FolderEnumerationMode AccessBased -CachingMode None | Out-Null
    New-SmbShare -Name "Governance"  -Path $GovernanceRoot -FullAccess "BUILTIN\Administrators", "$NetBIOS\GG_LAB_BreakGlass" -ChangeAccess "$NetBIOS\GG_Board_Members", "$NetBIOS\GG_LAB_Directors" -FolderEnumerationMode AccessBased -CachingMode None | Out-Null
    New-SmbShare -Name "Shared"      -Path $SharedRoot -FullAccess "BUILTIN\Administrators", "$NetBIOS\GG_LAB_BreakGlass", "$NetBIOS\GG_LAB_Admins" -ChangeAccess "$NetBIOS\GG_LAB_AllUsers" -FolderEnumerationMode AccessBased -CachingMode None | Out-Null

} -ArgumentList $ShareRoot,$DeptRoot,$GovernanceRoot,$BoardRoot,$BoardOnlyPath,$BoardDirPath,$SharedRoot,$Departments,$NetBIOS

Write-Host "[OK] 08 completato." -ForegroundColor Green
