# ============================================================
# LAB Active Directory - 00-Init-LAB-Session.ps1
# Inizializzazione variabili, moduli e transcript
# Idempotente / rieseguibile
# Da eseguire su DC01 come amministratore di dominio
# ============================================================

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "=== 00 - Inizializzazione sessione LAB AD ===" -ForegroundColor Cyan
Write-Host ""

# Percorsi standard
$Global:LABRoot    = "C:\LAB-AD"
$Global:ScriptRoot = Join-Path $Global:LABRoot "Scripts"
$Global:LogRoot    = Join-Path $Global:LABRoot "Logs"
$Global:ReportRoot = Join-Path $Global:LABRoot "Reports"

foreach ($Path in @($Global:LABRoot, $Global:ScriptRoot, $Global:LogRoot, $Global:ReportRoot, "C:\Temp")) {
    New-Item -Path $Path -ItemType Directory -Force | Out-Null
}

# Verifica privilegi amministrativi locali
$CurrentIdentity = [Security.Principal.WindowsIdentity]::GetCurrent()
$Principal = New-Object Security.Principal.WindowsPrincipal($CurrentIdentity)
if (-not $Principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Esegui PowerShell come amministratore."
}
Write-Host "[OK] PowerShell elevato." -ForegroundColor Green

# Import moduli
Import-Module ActiveDirectory -ErrorAction Stop
Import-Module GroupPolicy -ErrorAction Stop
Write-Host "[OK] Moduli ActiveDirectory e GroupPolicy importati." -ForegroundColor Green

# Dominio
$Global:Domain    = Get-ADDomain -ErrorAction Stop
$Global:DomainDN  = $Global:Domain.DistinguishedName
$Global:DomainDNS = $Global:Domain.DNSRoot
$Global:NetBIOS   = $Global:Domain.NetBIOSName

# Perimetro LAB
$Global:LabOUName = "LAB"
$Global:LabDN     = "OU=$Global:LabOUName,$Global:DomainDN"

# Dipartimenti e governance
$Global:Departments = @("IT", "Finance", "HR", "Marketing", "Sales")
$Global:GovernanceUnits = @("Board")

# Server naming previsti dal disegno del lab
# Attualmente attivo: SRV-FS-001
# Futuri server previsti: SRV-APP-001, SRV-DB-001, altri aggiungibili seguendo la stessa convenzione.
$Global:FileServerName = "SRV-FS-001"
$Global:AppServerNames = @("SRV-APP-001")
$Global:DbServerNames  = @("SRV-DB-001")
$Global:AllMemberServerNames = @($Global:FileServerName) + $Global:AppServerNames + $Global:DbServerNames

# File server paths
$Global:ShareRoot      = "D:\Shares"
$Global:DeptRoot       = Join-Path $Global:ShareRoot "Departments"
$Global:GovernanceRoot = Join-Path $Global:ShareRoot "Governance"
$Global:BoardRoot      = Join-Path $Global:GovernanceRoot "Board"
$Global:BoardOnlyPath  = Join-Path $Global:BoardRoot "BoardOnly"
$Global:BoardDirPath   = Join-Path $Global:BoardRoot "BoardDirectors"
$Global:SharedRoot     = Join-Path $Global:ShareRoot "Shared"

# Password di laboratorio. Cambiarle se necessario.
$Global:DefaultUserPassword = ConvertTo-SecureString "P@ssw0rd-LAB-ChangeMe!2026" -AsPlainText -Force
$Global:AdminPassword       = ConvertTo-SecureString "Adm1n-LAB-ChangeMe!2026" -AsPlainText -Force
$Global:BreakGlassPassword  = ConvertTo-SecureString "BreakGlass-LAB-ChangeMe!2026" -AsPlainText -Force
$Global:HoneyPassword       = ConvertTo-SecureString "Honey-LAB-ChangeMe!2026" -AsPlainText -Force
$Global:ServicePassword     = ConvertTo-SecureString "Svc-LAB-ChangeMe!2026" -AsPlainText -Force

# Transcript, senza fallire se già attivo
$Global:TranscriptPath = Join-Path $Global:LogRoot "LAB-AD-Deploy-$(Get-Date -Format 'yyyyMMdd-HHmmss').log"
try {
    Start-Transcript -Path $Global:TranscriptPath -ErrorAction Stop | Out-Null
    $Global:LAB_TranscriptStarted = $true
    Write-Host "[OK] Transcript avviato: $Global:TranscriptPath" -ForegroundColor Green
}
catch {
    Write-Warning "Transcript non avviato, forse già attivo. Dettaglio: $_"
}

Write-Host ""
Write-Host "=== Variabili principali ===" -ForegroundColor Cyan
Write-Host "DomainDNS              = $Global:DomainDNS"
Write-Host "DomainDN               = $Global:DomainDN"
Write-Host "NetBIOS                = $Global:NetBIOS"
Write-Host "LabDN                  = $Global:LabDN"
Write-Host "FileServerName         = $Global:FileServerName"
Write-Host "ShareRoot              = $Global:ShareRoot"
Write-Host "Member server previsti = $($Global:AllMemberServerNames -join ', ')"
Write-Host ""
Write-Host "[OK] 00 completato." -ForegroundColor Green
