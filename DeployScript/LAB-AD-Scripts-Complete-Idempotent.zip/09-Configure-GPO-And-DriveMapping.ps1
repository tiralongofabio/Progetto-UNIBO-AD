# ============================================================
# LAB Active Directory - 09-Configure-GPO-And-DriveMapping.ps1
# GPO complete, link e drive mapping Departments/Governance
# Idempotente
# ============================================================

$ErrorActionPreference = "Stop"
$ScriptRoot = "C:\LAB-AD\Scripts"
if (-not $Global:LabDN) { & (Join-Path $ScriptRoot "00-Init-LAB-Session.ps1") }
if (-not (Get-Command Ensure-GPOWithLink -ErrorAction SilentlyContinue)) { . (Join-Path $ScriptRoot "01-Load-LAB-Helpers.ps1") }

$OU_Computers    = "OU=Computers,$LabDN"
$OU_Workstations = "OU=Workstations,OU=Computers,$LabDN"
$OU_Servers      = "OU=Servers,OU=Computers,$LabDN"
$OU_FileServers  = "OU=FileServers,OU=Servers,OU=Computers,$LabDN"
$OU_AppServers   = "OU=AppServers,OU=Servers,OU=Computers,$LabDN"
$OU_DBServers    = "OU=DBServers,OU=Servers,OU=Computers,$LabDN"
$OU_Admins       = "OU=Admins,$LabDN"
$OU_Departments  = "OU=Departments,$LabDN"
$OU_Governance   = "OU=Governance,$LabDN"
$OU_Staging      = "OU=Staging,OU=Computers,$LabDN"

Ensure-GPOWithLink -Name "GPO-LAB-Baseline-Computers"       -TargetDN $OU_Computers    -Comment "LAB computer baseline"
Ensure-GPOWithLink -Name "GPO-LAB-Baseline-Users"           -TargetDN $OU_Departments  -Comment "LAB department user baseline"
Ensure-GPOWithLink -Name "GPO-LAB-Governance-Users"         -TargetDN $OU_Governance   -Comment "LAB governance user baseline"
Ensure-GPOWithLink -Name "GPO-LAB-Workstations-Hardening"   -TargetDN $OU_Workstations -Comment "LAB workstation hardening"
Ensure-GPOWithLink -Name "GPO-LAB-Servers-Hardening"        -TargetDN $OU_Servers      -Comment "LAB server hardening"
Ensure-GPOWithLink -Name "GPO-LAB-FileServers-Hardening"    -TargetDN $OU_FileServers  -Comment "LAB file server hardening"
Ensure-GPOWithLink -Name "GPO-LAB-AppServers-Hardening"     -TargetDN $OU_AppServers   -Comment "LAB app server hardening predisposed"
Ensure-GPOWithLink -Name "GPO-LAB-DBServers-Hardening"      -TargetDN $OU_DBServers    -Comment "LAB DB server hardening predisposed"
Ensure-GPOWithLink -Name "GPO-LAB-Admins-Restrictions"      -TargetDN $OU_Admins       -Comment "LAB admin account restrictions"
Ensure-GPOWithLink -Name "GPO-LAB-Staging-Quarantine"       -TargetDN $OU_Staging      -Comment "LAB staging quarantine policy"
Ensure-GPOWithLink -Name "GPO-LAB-DriveMapping"             -TargetDN $OU_Departments  -Comment "LAB department drive mapping"
Ensure-GPOWithLink -Name "GPO-LAB-Governance-DriveMapping"  -TargetDN $OU_Governance   -Comment "LAB governance drive mapping"

# Impostazioni minime registry-based
Set-GPRegistryValue -Name "GPO-LAB-Baseline-Computers" -Key "HKLM\Software\Policies\Microsoft\WindowsFirewall\DomainProfile" -ValueName "EnableFirewall" -Type DWord -Value 1
Set-GPRegistryValue -Name "GPO-LAB-Baseline-Computers" -Key "HKLM\System\CurrentControlSet\Control\Lsa" -ValueName "NoLMHash" -Type DWord -Value 1
Set-GPRegistryValue -Name "GPO-LAB-Servers-Hardening" -Key "HKLM\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" -ValueName "UserAuthentication" -Type DWord -Value 1
Set-GPRegistryValue -Name "GPO-LAB-Baseline-Users" -Key "HKCU\Software\Policies\Microsoft\Windows\Control Panel\Desktop" -ValueName "ScreenSaveTimeOut" -Type String -Value "900"
Set-GPRegistryValue -Name "GPO-LAB-Baseline-Users" -Key "HKCU\Software\Policies\Microsoft\Windows\Control Panel\Desktop" -ValueName "ScreenSaverIsSecure" -Type String -Value "1"
Set-GPRegistryValue -Name "GPO-LAB-Governance-Users" -Key "HKCU\Software\Policies\Microsoft\Windows\Control Panel\Desktop" -ValueName "ScreenSaveTimeOut" -Type String -Value "600"
Set-GPRegistryValue -Name "GPO-LAB-Governance-Users" -Key "HKCU\Software\Policies\Microsoft\Windows\Control Panel\Desktop" -ValueName "ScreenSaverIsSecure" -Type String -Value "1"

# Drive mapping scripts in SYSVOL
$ScriptsPath = "\\$DomainDNS\SYSVOL\$DomainDNS\scripts"
New-Item -Path $ScriptsPath -ItemType Directory -Force | Out-Null

$MapScriptPath = Join-Path $ScriptsPath "Map-LABDrives.ps1"
$MapScript = @'
$Domain = $env:USERDOMAIN
function Test-GroupMembership {
    param([string]$GroupName)
    try {
        $Current = [Security.Principal.WindowsIdentity]::GetCurrent()
        $Principal = New-Object Security.Principal.WindowsPrincipal($Current)
        return $Principal.IsInRole("$Domain\$GroupName")
    } catch { return $false }
}
New-PSDrive -Name "S" -PSProvider FileSystem -Root "\\SRV-FS-001\Shared" -Persist -ErrorAction SilentlyContinue | Out-Null
foreach ($Dept in @("IT", "Finance", "HR", "Marketing", "Sales")) {
    if (Test-GroupMembership -GroupName "GG_${Dept}_Users") {
        New-PSDrive -Name "H" -PSProvider FileSystem -Root "\\SRV-FS-001\Departments\$Dept\Internal" -Persist -ErrorAction SilentlyContinue | Out-Null
    }
}
'@
Set-Content -Path $MapScriptPath -Value $MapScript -Encoding UTF8

$GovMapScriptPath = Join-Path $ScriptsPath "Map-LABGovernanceDrives.ps1"
$GovMapScript = @'
$Domain = $env:USERDOMAIN
function Test-GroupMembership {
    param([string]$GroupName)
    try {
        $Current = [Security.Principal.WindowsIdentity]::GetCurrent()
        $Principal = New-Object Security.Principal.WindowsPrincipal($Current)
        return $Principal.IsInRole("$Domain\$GroupName")
    } catch { return $false }
}
if (Test-GroupMembership -GroupName "GG_Board_Members") {
    New-PSDrive -Name "O" -PSProvider FileSystem -Root "\\SRV-FS-001\Governance\Board\BoardOnly" -Persist -ErrorAction SilentlyContinue | Out-Null
}
if ((Test-GroupMembership -GroupName "GG_Board_Members") -or (Test-GroupMembership -GroupName "GG_LAB_Directors")) {
    New-PSDrive -Name "G" -PSProvider FileSystem -Root "\\SRV-FS-001\Governance\Board\BoardDirectors" -Persist -ErrorAction SilentlyContinue | Out-Null
}
'@
Set-Content -Path $GovMapScriptPath -Value $GovMapScript -Encoding UTF8

Set-GPRegistryValue -Name "GPO-LAB-DriveMapping" -Key "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" -ValueName "LABDriveMapping" -Type String -Value "powershell.exe -ExecutionPolicy Bypass -WindowStyle Hidden -File `"\\$DomainDNS\SYSVOL\$DomainDNS\scripts\Map-LABDrives.ps1`""
Set-GPRegistryValue -Name "GPO-LAB-Governance-DriveMapping" -Key "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" -ValueName "LABGovernanceDriveMapping" -Type String -Value "powershell.exe -ExecutionPolicy Bypass -WindowStyle Hidden -File `"\\$DomainDNS\SYSVOL\$DomainDNS\scripts\Map-LABGovernanceDrives.ps1`""

Write-Host "[OK] 09 completato." -ForegroundColor Green
