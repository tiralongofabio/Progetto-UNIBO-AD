# ============================================================
# LAB Active Directory - 06-Place-Computer-Accounts.ps1
# Spostamento computer account nelle OU corrette e predisposizione futuri server
# Idempotente
# ============================================================

$ErrorActionPreference = "Stop"
$ScriptRoot = "C:\LAB-AD\Scripts"
if (-not $Global:LabDN) { & (Join-Path $ScriptRoot "00-Init-LAB-Session.ps1") }
Import-Module ActiveDirectory -ErrorAction Stop

function Move-ComputerIfExists {
    param([string]$ComputerName, [string]$TargetOU)
    $Computer = Get-ADComputer -Identity $ComputerName -ErrorAction SilentlyContinue
    if ($Computer) {
        if ($Computer.DistinguishedName -notlike "*$TargetOU") {
            Move-ADObject -Identity $Computer.DistinguishedName -TargetPath $TargetOU
            Write-Host "[OK] Spostato $ComputerName -> $TargetOU" -ForegroundColor Green
        } else {
            Write-Host "[SKIP] $ComputerName già in OU corretta." -ForegroundColor Yellow
        }
    } else {
        Write-Warning "$ComputerName non esiste ancora in AD. Non bloccante."
    }
}

# Non spostare DC01: deve restare in Domain Controllers.
Move-ComputerIfExists -ComputerName "CLI01"      -TargetOU "OU=Workstations,OU=Computers,$LabDN"
Move-ComputerIfExists -ComputerName "SRV-FS-001" -TargetOU "OU=FileServers,OU=Servers,OU=Computers,$LabDN"

# Futuri server, già predisposti. Scommentare quando esisteranno/joined.
# Move-ComputerIfExists -ComputerName "SRV-APP-001" -TargetOU "OU=AppServers,OU=Servers,OU=Computers,$LabDN"
# Move-ComputerIfExists -ComputerName "SRV-DB-001"  -TargetOU "OU=DBServers,OU=Servers,OU=Computers,$LabDN"

Write-Host "[OK] 06 completato." -ForegroundColor Green
