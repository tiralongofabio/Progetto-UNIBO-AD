# ============================================================
# LAB Active Directory - 03-Create-LAB-Groups.ps1
# Creazione gruppi completa secondo modello AGDLP
# Idempotente
# ============================================================

$ErrorActionPreference = "Stop"
$ScriptRoot = "C:\LAB-AD\Scripts"
if (-not $Global:LabDN) { & (Join-Path $ScriptRoot "00-Init-LAB-Session.ps1") }
if (-not (Get-Command Ensure-ADGroup -ErrorAction SilentlyContinue)) { . (Join-Path $ScriptRoot "01-Load-LAB-Helpers.ps1") }

Write-Host ""
Write-Host "=== 03 - Creazione gruppi LAB ===" -ForegroundColor Cyan

$GroupsSecurityDN = "OU=Security,OU=Groups,$LabDN"
if (-not (Get-ADOrganizationalUnit -Identity $GroupsSecurityDN -ErrorAction SilentlyContinue)) {
    throw "OU gruppi mancante: $GroupsSecurityDN. Esegui prima 02-Create-LAB-OUs.ps1"
}

# Global Group identità/ruoli
Ensure-ADGroup -Name "GG_LAB_AllUsers"    -Path $GroupsSecurityDN -Scope Global -Description "All standard LAB users"
Ensure-ADGroup -Name "GG_LAB_Directors"   -Path $GroupsSecurityDN -Scope Global -Description "All LAB directors"
Ensure-ADGroup -Name "GG_LAB_Admins"      -Path $GroupsSecurityDN -Scope Global -Description "LAB separated admin accounts"
Ensure-ADGroup -Name "GG_LAB_BreakGlass"  -Path $GroupsSecurityDN -Scope Global -Description "LAB emergency access accounts"
Ensure-ADGroup -Name "GG_Board_Members"   -Path $GroupsSecurityDN -Scope Global -Description "LAB Board members"
Ensure-ADGroup -Name "GG_SecurityApp"     -Path $GroupsSecurityDN -Scope Global -Description "LAB security application/service accounts"
Ensure-ADGroup -Name "GG_LAB_HoneyObjects" -Path $GroupsSecurityDN -Scope Global -Description "LAB honey/decoy accounts - no real privileges"

foreach ($Dept in $Departments) {
    Ensure-ADGroup -Name "GG_${Dept}_Users"    -Path $GroupsSecurityDN -Scope Global -Description "$Dept standard users"
    Ensure-ADGroup -Name "GG_${Dept}_Director" -Path $GroupsSecurityDN -Scope Global -Description "$Dept director"
}

# Domain Local Group file server
Ensure-ADGroup -Name "DL_FS_Shared_RO" -Path $GroupsSecurityDN -Scope DomainLocal -Description "RO on global Shared share"
Ensure-ADGroup -Name "DL_FS_Shared_MD" -Path $GroupsSecurityDN -Scope DomainLocal -Description "MD on global Shared share"
Ensure-ADGroup -Name "DL_FS_Shared_FC" -Path $GroupsSecurityDN -Scope DomainLocal -Description "FC on global Shared share"

foreach ($Dept in $Departments) {
    Ensure-ADGroup -Name "DL_FS_${Dept}_Public_WO"       -Path $GroupsSecurityDN -Scope DomainLocal -Description "$Dept Public add-only/drop-box"
    Ensure-ADGroup -Name "DL_FS_${Dept}_Public_MD"       -Path $GroupsSecurityDN -Scope DomainLocal -Description "$Dept Public modify"
    Ensure-ADGroup -Name "DL_FS_${Dept}_Public_RO"       -Path $GroupsSecurityDN -Scope DomainLocal -Description "$Dept Public read-only"
    Ensure-ADGroup -Name "DL_FS_${Dept}_Public_FC"       -Path $GroupsSecurityDN -Scope DomainLocal -Description "$Dept Public full control"
    Ensure-ADGroup -Name "DL_FS_${Dept}_Internal_MD"     -Path $GroupsSecurityDN -Scope DomainLocal -Description "$Dept Internal modify"
    Ensure-ADGroup -Name "DL_FS_${Dept}_Internal_FC"     -Path $GroupsSecurityDN -Scope DomainLocal -Description "$Dept Internal full control"
    Ensure-ADGroup -Name "DL_FS_${Dept}_Confidential_MD" -Path $GroupsSecurityDN -Scope DomainLocal -Description "$Dept Confidential modify"
    Ensure-ADGroup -Name "DL_FS_${Dept}_Confidential_FC" -Path $GroupsSecurityDN -Scope DomainLocal -Description "$Dept Confidential full control"
}

Ensure-ADGroup -Name "DL_FS_Governance_BoardOnly_MD"      -Path $GroupsSecurityDN -Scope DomainLocal -Description "Modify access to Board-only governance documents"
Ensure-ADGroup -Name "DL_FS_Governance_BoardOnly_FC"      -Path $GroupsSecurityDN -Scope DomainLocal -Description "Full control on Board-only governance documents"
Ensure-ADGroup -Name "DL_FS_Governance_BoardDirectors_MD" -Path $GroupsSecurityDN -Scope DomainLocal -Description "Modify access to Board and Directors shared governance documents"
Ensure-ADGroup -Name "DL_FS_Governance_BoardDirectors_FC" -Path $GroupsSecurityDN -Scope DomainLocal -Description "Full control on Board and Directors shared governance documents"

# RDP per tipologie server previste
Ensure-ADGroup -Name "DL_RDP_SRV-FS-001_Admins"  -Path $GroupsSecurityDN -Scope DomainLocal -Description "RDP admins on SRV-FS-001"
Ensure-ADGroup -Name "DL_RDP_SRV-APP-001_Admins" -Path $GroupsSecurityDN -Scope DomainLocal -Description "RDP admins on future SRV-APP-001"
Ensure-ADGroup -Name "DL_RDP_SRV-DB-001_Admins"  -Path $GroupsSecurityDN -Scope DomainLocal -Description "RDP admins on future SRV-DB-001"

# Gruppi server-role per GPO/security filtering futuri
Ensure-ADGroup -Name "GG_LAB_FileServers" -Path $GroupsSecurityDN -Scope Global -Description "LAB file server computer accounts"
Ensure-ADGroup -Name "GG_LAB_AppServers"  -Path $GroupsSecurityDN -Scope Global -Description "LAB application server computer accounts"
Ensure-ADGroup -Name "GG_LAB_DBServers"   -Path $GroupsSecurityDN -Scope Global -Description "LAB database server computer accounts"

Write-Host ""
$AllLabGroups = Get-ADGroup -SearchBase $GroupsSecurityDN -Filter * -Properties Description | Sort-Object Name
$AllLabGroups | Select-Object Name, GroupScope, GroupCategory, Description | Format-Table -AutoSize
Write-Host "Totale gruppi presenti: $($AllLabGroups.Count)" -ForegroundColor Cyan
Write-Host "[OK] 03 completato." -ForegroundColor Green
