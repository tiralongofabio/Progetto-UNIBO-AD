# ============================================================
# LAB Active Directory - 02-Create-LAB-OUs.ps1
# Creazione struttura OU completa
# Idempotente
# ============================================================

$ErrorActionPreference = "Stop"
$ScriptRoot = "C:\LAB-AD\Scripts"
if (-not $Global:LabDN) { & (Join-Path $ScriptRoot "00-Init-LAB-Session.ps1") }
if (-not (Get-Command Ensure-ADOU -ErrorAction SilentlyContinue)) { . (Join-Path $ScriptRoot "01-Load-LAB-Helpers.ps1") }

Write-Host ""
Write-Host "=== 02 - Creazione struttura OU ===" -ForegroundColor Cyan

Ensure-ADOU -Name "LAB" -Path $DomainDN -Description "LAB root OU"

Ensure-ADOU -Name "Departments"     -Path $LabDN -Description "LAB operational departments"
Ensure-ADOU -Name "Governance"      -Path $LabDN -Description "LAB governance units"
Ensure-ADOU -Name "Admins"          -Path $LabDN -Description "LAB admin accounts"
Ensure-ADOU -Name "Groups"          -Path $LabDN -Description "LAB groups"
Ensure-ADOU -Name "ServiceAccounts" -Path $LabDN -Description "LAB service accounts"
Ensure-ADOU -Name "Computers"       -Path $LabDN -Description "LAB computers"

foreach ($Dept in $Departments) {
    Ensure-ADOU -Name $Dept -Path "OU=Departments,$LabDN" -Description "LAB department: $Dept"
}

Ensure-ADOU -Name "Board" -Path "OU=Governance,$LabDN" -Description "LAB governance unit: Board"

Ensure-ADOU -Name "IT-Admins"   -Path "OU=Admins,$LabDN" -Description "LAB IT admin accounts"
Ensure-ADOU -Name "Break-Glass" -Path "OU=Admins,$LabDN" -Description "LAB emergency accounts"
Ensure-ADOU -Name "Honey-Objects" -Path "OU=Admins,$LabDN" -Description "LAB decoy/honey accounts"

Ensure-ADOU -Name "Security"     -Path "OU=Groups,$LabDN" -Description "LAB security groups"
Ensure-ADOU -Name "Distribution" -Path "OU=Groups,$LabDN" -Description "LAB distribution groups"

Ensure-ADOU -Name "UserManagedServiceAccounts" -Path "OU=ServiceAccounts,$LabDN" -Description "LAB traditional service accounts"
Ensure-ADOU -Name "gMSA"                       -Path "OU=ServiceAccounts,$LabDN" -Description "LAB group managed service accounts"
Ensure-ADOU -Name "SecurityApp"                -Path "OU=ServiceAccounts,$LabDN" -Description "LAB security application accounts"

Ensure-ADOU -Name "Staging"      -Path "OU=Computers,$LabDN" -Description "LAB staging/quarantine computers"
Ensure-ADOU -Name "Workstations" -Path "OU=Computers,$LabDN" -Description "LAB workstations"
Ensure-ADOU -Name "Servers"      -Path "OU=Computers,$LabDN" -Description "LAB member servers"
Ensure-ADOU -Name "FileServers"  -Path "OU=Servers,OU=Computers,$LabDN" -Description "LAB file servers"
Ensure-ADOU -Name "AppServers"   -Path "OU=Servers,OU=Computers,$LabDN" -Description "LAB application servers"
Ensure-ADOU -Name "DBServers"    -Path "OU=Servers,OU=Computers,$LabDN" -Description "LAB database servers"

# Redirect opzionale dei container predefiniti. Scommentare solo se desiderato.
# redirusr "OU=Departments,$LabDN"
# redircmp "OU=Staging,OU=Computers,$LabDN"

Write-Host "[OK] 02 completato." -ForegroundColor Green
