# ============================================================
# LAB Active Directory - 11-Configure-HoneyObject-Auditing.ps1
# Setup base honey-object e monitor locale semplificato
# Idempotente
# ============================================================

$ErrorActionPreference = "Stop"
$ScriptRoot = "C:\LAB-AD\Scripts"
if (-not $Global:LabDN) { & (Join-Path $ScriptRoot "00-Init-LAB-Session.ps1") }

# L'account admin.backup viene creato nello script 04 e inserito in GG_LAB_HoneyObjects nello script 05.
# Qui predisponiamo un monitor locale semplificato su DC01. Test più approfonditi saranno in documento dedicato.

$HoneyMonitorScript = "C:\Scripts\Monitor-HoneyObject.ps1"
New-Item -Path (Split-Path $HoneyMonitorScript) -ItemType Directory -Force | Out-Null
@'
$Events = Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4624,4625,4728,4732,4756; StartTime=(Get-Date).AddMinutes(-15)} -ErrorAction SilentlyContinue |
    Where-Object { $_.Message -like "*admin.backup*" }
if ($Events) {
    $Out = "C:\Temp\LAB-HoneyObject-Alert.log"
    New-Item -Path (Split-Path $Out) -ItemType Directory -Force | Out-Null
    $Events | Select-Object TimeCreated, Id, ProviderName, Message | Out-File -FilePath $Out -Append
}
'@ | Set-Content -Path $HoneyMonitorScript -Encoding UTF8

$TaskName = "LAB-Monitor-HoneyObject"
if (-not (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue)) {
    $Action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-ExecutionPolicy Bypass -File $HoneyMonitorScript"
    $Trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 15) -RepetitionDuration (New-TimeSpan -Days 3650)
    Register-ScheduledTask -TaskName $TaskName -Action $Action -Trigger $Trigger -RunLevel Highest -Description "Monitor LAB honey object admin.backup" | Out-Null
    Write-Host "[OK] Scheduled task creata: $TaskName" -ForegroundColor Green
} else {
    Write-Host "[SKIP] Scheduled task già presente: $TaskName" -ForegroundColor Yellow
}

Write-Host "[OK] 11 completato." -ForegroundColor Green
